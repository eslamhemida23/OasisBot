# OasisBot – VBot API compatibility patch (مرحلة أولى)

هذه الملفات تضيف واجهة Legacy إلى Python API اعتمادًا على وظائف موجودة بالفعل في نسخة المصدر التي تمت مراجعتها.

## الملفات
- `Plugins/RSBot.Python/Components/API/Core/Legacy/API.Legacy.cs` – وحدة Python باسم `legacy`.
- `Plugins/RSBot.Python/Views/Main.cs` – ربط حدث استقبال الشات بـ Python callback.
- `Plugins/RSBot.Chat/Bundle/Network/ChatResponse.cs` – إرسال Event للقنوات غير All أيضًا.
- `Plugins/RSBot.Python/RSBot.Python.csproj` – إضافة مرجع Chat plugin لدوال الإرسال.

## الدوال المضافة في `legacy`
- `player_start_trace(player_name)` – يستخدم نفس Packet وبنية البيانات الموجودة بالفعل في `RSBot.Party/CommandsBundle.cs`؛ لا يخترع Opcode جديدًا.
- `party_leave()`
- `player_use_return_scroll()`
- `player_use_health_potion()`
- `player_use_mana_potion()`
- `player_enter_berzerk()`
- `inventory_use_slot(slot)`
- `inventory_move(from_slot, to_slot)`
- `world_get_portals()` – يعيد البوابات وروابطها المرجعية المحملة.
- `world_get_entity(uid)`

## دمج التعديل
1. خذ نسخة احتياطية من مجلد `Plugins/RSBot.Python`.
2. انسخ `API.Legacy.cs` إلى `Plugins/RSBot.Python/Components/API/Core/Legacy/`.
3. استبدل الملفات المطابقة داخل مشروعك بنظائرها في الحزمة، بعد مقارنة أي تعديلات خاصة عندك وعدم الكتابة فوقها.
4. افتح الحل الأصلي وابنِ باستخدام MSBuild/Build Script المرفق بالمشروع، وليس `dotnet build`.

## وحدة `chat` الجديدة
- `send(chat_type, message, receiver=None)`
- `send_all(message)`، `send_party(message)`، `send_guild(message)`، `send_union(message)`، `send_global(message)`، `send_private(player_name, message)`

ويُستقبل الشات عبر `on_chat_message(chat_type, sender, message)`، وأنواع الشات تحتفظ بأرقام OasisBot: All=1، Private=2، Party=4، Guild=5، Global=6، Notice=7، Stall=9، Union=11، Academy=16.

## مهم – ما لم يُنفذ بعد
- لم أضف `player_stop_trace()`؛ لم أجد في مصدر OasisBot الذي فُحص تنفيذًا موثوقًا لإيقاف التتبع. لا يصح تخمين payload لهذا الأمر.
- لم أضف إرسال الشات؛ استقبال الشات فقط موجود هنا. الإرسال يحتاج ربط ChatManager plugin أو API معتمد.
- لم أضف teleport execution، pets API، config get/set/save، packet builder/handlers، أو استكمال كل خصائص GUI.
- لا يوجد تفاعل NPC أو اختيار Teleport ضمن هذه الدفعة؛ `world_get_portals()` يعرض البوابات وروابطها فقط.

هذا Patch أولي وليس إصدارًا نهائيًا مطابقًا لـ VBot. يجب بناء المشروع واختبار كل دالة داخل اللعبة قبل الاعتماد عليه.
