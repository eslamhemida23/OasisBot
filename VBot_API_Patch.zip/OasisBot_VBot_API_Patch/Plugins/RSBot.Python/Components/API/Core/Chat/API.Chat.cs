using RSBot.Chat;
using RSBot.Core.Objects;
using RSBot.Python.Components.API.Interface;
using RSBot.Python.Views;

namespace RSBot.Python.Components.API.Core.Chat;

/// <summary>Chat sending compatibility API.</summary>
public sealed class ChatAPI : IPythonPlugin
{
    public string ModuleName => "chat";
    public void Init(Main main) { }

    public bool send(int chatType, string message, string receiver = null)
    {
        if (string.IsNullOrWhiteSpace(message)) return false;
        if (!System.Enum.IsDefined(typeof(ChatType), chatType)) return false;
        ChatManager.Send((ChatType)chatType, message, receiver);
        return true;
    }

    public bool send_all(string message) => send((int)ChatType.All, message);
    public bool send_party(string message) => send((int)ChatType.Party, message);
    public bool send_guild(string message) => send((int)ChatType.Guild, message);
    public bool send_union(string message) => send((int)ChatType.Union, message);
    public bool send_global(string message) => send((int)ChatType.Global, message);
    public bool send_private(string playerName, string message) => send((int)ChatType.Private, message, playerName);
}
