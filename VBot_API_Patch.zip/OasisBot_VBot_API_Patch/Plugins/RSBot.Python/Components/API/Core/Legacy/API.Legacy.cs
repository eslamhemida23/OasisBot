﻿using System;
using System.Collections.Generic;
using System.Linq;
using Python.Runtime;
using RSBot.Core;
using RSBot.Core.Components;
using RSBot.Core.Extensions;
using RSBot.Core.Network;
using RSBot.Core.Objects;
using RSBot.Core.Objects.Spawn;
using RSBot.Python.Components.API.Interface;
using RSBot.Python.Views;

namespace RSBot.Python.Components.API.Core.Legacy;

/// <summary>Compatibility surface for porting vBot scripts to OasisBot Python.</summary>
public sealed class LegacyAPI : IPythonPlugin
{
    public string ModuleName => "legacy";
    public void Init(Main main) { }

    public bool player_start_trace(string playerName)
    {
        if (Game.Player == null || string.IsNullOrWhiteSpace(playerName)) return false;
        if (!SpawnManager.TryGetEntity<SpawnedPlayer>(p =>
                string.Equals(p.Name, playerName, StringComparison.OrdinalIgnoreCase), out var target))
            return false;

        // Same packet structure already used by OasisBot's Party.CommandsBundle.
        var packet = new Packet(0x7074);
        packet.WriteByte(1);
        packet.WriteByte(3);
        packet.WriteByte(1);
        packet.WriteUInt(target.UniqueId);
        PacketManager.SendPacket(packet, PacketDestination.Server);
        return true;
    }

    public bool party_leave()
    {
        if (Game.Party == null || !Game.Party.IsInParty) return false;
        Game.Party.Leave();
        return true;
    }

    public bool player_use_return_scroll() => Game.Player?.UseReturnScroll() ?? false;
    public bool player_use_health_potion() => Game.Player?.UseHealthPotion() ?? false;
    public bool player_use_mana_potion() => Game.Player?.UseManaPotion() ?? false;

    public bool player_enter_berzerk()
    {
        if (Game.Player == null || !Game.Player.CanEnterBerzerk) return false;
        Game.Player.EnterBerzerkMode();
        return true;
    }

    public bool inventory_use_slot(byte slot)
    {
        var item = Game.Player?.Inventory?.GetItemAt(slot);
        return item?.Use() ?? false;
    }

    public bool inventory_move(byte fromSlot, byte toSlot)
    {
        return Game.Player?.Inventory?.MoveItem(fromSlot, toSlot) ?? false;
    }

    public PyList world_get_portals()
    {
        using (Py.GIL())
        {
            var result = new PyList();
            if (!SpawnManager.TryGetEntities<SpawnedPortal>(out var portals)) return result;
            foreach (var portal in portals)
            {
                if (portal == null) continue;
                var row = new PyDict();
                row.SetItem(new PyString("uid"), new PyInt(portal.UniqueId));
                row.SetItem(new PyString("model"), new PyInt(portal.Id));
                row.SetItem(new PyString("x"), new PyFloat(portal.Position.X));
                row.SetItem(new PyString("y"), new PyFloat(portal.Position.Y));
                row.SetItem(new PyString("z"), new PyFloat(portal.Position.ZOffset));
                row.SetItem(new PyString("region"), new PyInt(portal.Position.Region));
                row.SetItem(new PyString("name"), new PyString(portal.Record?.GetRealName() ?? string.Empty));
                var links = new PyList();
                foreach (var link in portal.Links ?? new List<RSBot.Core.Client.ReferenceObjects.RefTeleportLink>())
                {
                    var l = new PyDict();
                    l.SetItem(new PyString("owner_teleport"), new PyInt(link.OwnerTeleport));
                    l.SetItem(new PyString("target_teleport"), new PyInt(link.TargetTeleport));
                    links.Append(l);
                }
                row.SetItem(new PyString("links"), links);
                result.Append(row);
            }
            return result;
        }
    }

    public PyDict world_get_entity(uint uniqueId)
    {
        using (Py.GIL())
        {
            var result = new PyDict();
            if (!SpawnManager.TryGetEntityIncludingMe(uniqueId, out var entity)) return result;
            result.SetItem(new PyString("uid"), new PyInt(entity.UniqueId));
            result.SetItem(new PyString("model"), new PyInt(entity.Id));
            result.SetItem(new PyString("x"), new PyFloat(entity.Position.X));
            result.SetItem(new PyString("y"), new PyFloat(entity.Position.Y));
            result.SetItem(new PyString("z"), new PyFloat(entity.Position.ZOffset));
            result.SetItem(new PyString("region"), new PyInt(entity.Position.Region));
            if (entity is SpawnedPlayer player)
                result.SetItem(new PyString("name"), new PyString(player.Name ?? string.Empty));
            else
                result.SetItem(new PyString("name"), new PyString(entity.Record?.GetRealName() ?? string.Empty));
            return result;
        }
    }
}
