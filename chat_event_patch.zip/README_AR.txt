تعديل إضافة استقبال الشات لإضافات Python في OasisBot

الملفات:
1) Plugins/RSBot.Chat/Bundle/Network/ChatResponse.cs
   - يطلق EventManager event باسم OnChatMessageReceived بعد تحليل رسالة الشات.
   - يمرر نوع الرسالة كـ byte، واسم المرسل، ونص الرسالة.
   - يحافظ على معالجة واجهة الشات الحالية وحدث OnMessageReceived.

2) Plugins/RSBot.Python/Views/Main.cs
   - يشترك في OnChatMessageReceived.
   - يمرر الرسالة إلى إضافات Python عبر callback اسمه on_chat_message.

توقيع حدث Python:
    def on_chat_message(chat_type, sender, message):
        ...

قيم chat_type وفق ChatType في السورس:
    1  All
    2  Private
    3  AllGM
    4  Party
    5  Guild
    6  Global
    7  Notice
    9  Stall
    11 Union
    13 Npc (لا يتم تمريره حاليًا لأن محلل NPC غير مطبق)
    16 Academy

مثال:
    def on_chat_message(chat_type, sender, message):
        if chat_type == 4 and message.strip().upper() == "START":
            RSBot.start_bot()

ملاحظات:
- هذا Patch فقط، وليس نسخة كاملة من OasisBot.
- انسخ الملفين إلى نفس المسارات داخل سورس المشروع مع استبدالهما.
- يجب إعادة بناء المشروعين RSBot.Chat و RSBot.Python ثم تشغيل البوت المبني.
- لم أتمكن من تنفيذ build هنا لأن بيئة الفحص لا تحتوي على dotnet SDK.
- الحدث يلتقط الرسائل الواردة التي يعالجها ChatResponse (opcode 0x3026).
- هذا التعديل يضيف استقبال الشات فقط؛ لم يضف بعد API إرسال رسائل الشات من Python.
