OasisBot Python Plugin Auto-Activation + Chat Event Patch

This patch keeps the existing OnChatMessageReceived integration and adds persistent plugin activation.

Behavior:
- First launch: xControl_Oasis.py is enabled automatically if present. Other plugins remain disabled.
- User checkbox changes are saved in Data/Python/enabled_plugins.txt.
- On subsequent launches and Reload, saved enabled plugins are automatically loaded.
- Disabling a plugin removes it from the saved list.

Install: replace the existing chat_event_patch.zip in the repository root with this archive, commit the change, then rerun the existing GitHub Actions workflow.
The workflow must already extract chat_event_patch.zip into the repository before building RSBot.Python and RSBot.Chat.
