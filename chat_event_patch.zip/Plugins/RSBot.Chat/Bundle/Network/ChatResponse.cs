using System.Collections.Generic;
using System.Numerics;
using System.Text.RegularExpressions;
using RSBot.Chat.Views;
using RSBot.Core;
using RSBot.Core.Components;
using RSBot.Core.Event;
using RSBot.Core.Extensions;
using RSBot.Core.Network;
using RSBot.Core.Objects;
using RSBot.Core.Objects.Spawn;

namespace RSBot.Chat.Network;

internal class ChatResponse : IPacketHandler
{
    /// <summary>
    ///     Gets or sets the opcode.
    /// </summary>
    /// <value>
    ///     The opcode.
    /// </value>
    public ushort Opcode => 0x3026;

    /// <summary>
    ///     Gets or sets the destination.
    /// </summary>
    /// <value>
    ///     The destination.
    /// </value>
    public PacketDestination Destination => PacketDestination.Client;

    /// <summary>
    ///     Handles the packet.
    /// </summary>
    /// <param name="packet">The packet.</param>
    public void Invoke(Packet packet)
    {
        var type = (ChatType)packet.ReadByte();

        var message = string.Empty;
        var senderName = string.Empty;

        switch (type)
        {
            case ChatType.All:
            case ChatType.AllGM:
                var senderId = packet.ReadUInt();
                message = packet.ReadConditonalString();

                message = ReadChatWithLinkedItems(message);

                if (senderId != Game.Player.UniqueId)
                {
                    if (!SpawnManager.TryGetEntity<SpawnedPlayer>(senderId, out var player))
                        return;

                    senderName = player.Name;
                    EventManager.FireEvent("OnMessageReceived", message, senderName, ChatType.All);
                }
                else
                {
                    senderName = Game.Player.Name;
                    EventManager.FireEvent("OnMessageReceived", message, senderName, ChatType.All);
                }

                break;

            case ChatType.Notice:
                message = packet.ReadConditonalString();
                message = ReadChatWithLinkedItems(message);

                senderName = "Notice";
                View.Instance.AppendMessage(message, senderName, type);
                break;

            case ChatType.Npc:
                // NPC chat packet format is not implemented in the original handler.
                // Do not publish an event with incomplete sender/message data.
                return;

            default:
                senderName = packet.ReadString();
                message = packet.ReadConditonalString();

                message = ReadChatWithLinkedItems(message);

                View.Instance.AppendMessage(message, senderName, type);
                break;
        }

        // Public event consumed by Python plugins and other internal modules.
        EventManager.FireEvent("OnChatMessageReceived", (byte)type, senderName, message);
    }

    public static string ReadChatWithLinkedItems(string message)
    {
        const string pattern = "\u0002(.*?)\u0003";

        return Regex.Replace(
            message,
            pattern,
            match =>
            {
                string rawValue = match.Groups[1].Value;

                if (ulong.TryParse(rawValue, out ulong uid))
                {
                    if (Bundle.Chat.LinkedItems.TryGetValue(uid, out var data) && data.itemName != null)
                    {
                        bool hasSpaceBefore = match.Index > 0 && char.IsWhiteSpace(message[match.Index - 1]);

                        int endOfMatch = match.Index + match.Length;
                        bool hasSpaceAfter = endOfMatch < message.Length && char.IsWhiteSpace(message[endOfMatch]);

                        string leftPadding = hasSpaceBefore ? "" : " ";
                        string rightPadding = hasSpaceAfter ? "" : " ";

                        string displayName = data.amount > 1 ? $"{data.itemName} [{data.amount}]" : data.itemName;

                        return $"{leftPadding}< {displayName} >{rightPadding}";
                    }
                }
                return match.Value;
            }
        );
    }
}
