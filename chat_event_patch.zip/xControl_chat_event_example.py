# Example only: demonstrates the new Python chat callback.
# Chat type values are from RSBot.Core.Objects.ChatType.

CHAT_ALL = 1
CHAT_PRIVATE = 2
CHAT_PARTY = 4
CHAT_GUILD = 5
CHAT_UNION = 11

LEADERS = {"LeaderName".casefold()}

def on_chat_message(chat_type, sender, message):
    if not sender or sender.casefold() not in LEADERS:
        return

    command = (message or "").strip()
    if chat_type == CHAT_PARTY and command.upper() == "START":
        RSBot.start_bot()
    elif chat_type == CHAT_PARTY and command.upper() == "STOP":
        RSBot.stop_bot()
